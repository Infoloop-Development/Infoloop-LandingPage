INFOLOOP BRAND ASSETS
Official logos, tagline and guidelines for representing Infoloop
across digital and print media. From infoloop.co/brand-assets.

CONTENTS
--------
guidelines/   The brand book (PDF). Read this first.
logos/svg/    Vector masters. Source of truth for every icon and tile.
logos/png/    Transparent PNGs, 512 and 1024 px, plus the wordmark lockups
              (horizontal and stacked, two-tone, reversed and mono).
logos/pdf-vector/  True vector PDFs. Open and edit in Illustrator.
tagline/      "We build. We run." as PNG (light and dark) and SVG.

THE SHORT RULES
---------------
Colours   Ink #0A0A0A, Loop Orange #F47B00, White #FFFFFF.
          90% ink and white, 10% orange. Orange never carries body text.
Fonts     DM Sans (display and wordmark), Open Sans (text). Both free
          on Google Fonts.
Name      The wordmark is always lowercase: infoloop. In running text
          write Infoloop with a capital I. Never InfoLoop, Info Loop,
          INFOLOOP or info-loop.
Mark      Five bars, fixed proportions, the orange accent always on bar 2.
          Never redraw by eye: export from these masters.
Tagline   "We build. We run." Do not shorten, rewrite or restyle it, and
          do not use it without the logo.

Questions about usage: hi@infoloop.co
